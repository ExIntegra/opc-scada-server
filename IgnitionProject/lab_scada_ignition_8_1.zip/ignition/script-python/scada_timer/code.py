def run():
    import system
    import experiment

    expActivePath    = "[default]Exp/EXPERIMENT_ACTIVE"
    expIdPath        = "[default]Exp/EXPERIMENT_ID"
    valveStepPath    = "[default]Exp/VALVE_STEP_PCT"
    constParamPath   = "[default]Exp/CONST_PARAM"

    hc1OutPath       = "[default]Valves/HC-1/MANUAL_OUTPUT"
    hc3OutPath       = "[default]Valves/HC-3/MANUAL_OUTPUT"

    caPath           = "[default]Sensors/CRA-1/PROCESS_VALUE"   # CA
    cbPath           = "[default]Sensors/CRA-2/PROCESS_VALUE"   # CB
    qPath            = "[default]Sensors/FRA-1/PROCESS_VALUE"   # расход, л/мин
    tPath            = "[default]TRCA1/Sensor/PROCESS_VALUE"    # T, °C

    logger = system.util.getLogger("ScadaTimer")

    try:
        vals = system.tag.readBlocking([
            expActivePath, expIdPath, valveStepPath, constParamPath,
            hc1OutPath, hc3OutPath,
            caPath, cbPath, qPath, tPath
        ])

        exp_active   = bool(vals[0].value)
        exp_id       = vals[1].value
        valve_step   = float(vals[2].value or 0.0)
        const_param  = str(vals[3].value or "").upper()
        hc1_out      = float(vals[4].value or 0.0)
        hc3_out      = float(vals[5].value or 0.0)
        ca           = float(vals[6].value or 0.0)
        cb           = float(vals[7].value or 0.0)
        q_l_min      = float(vals[8].value or 0.0)
        t_c          = float(vals[9].value or 0.0)

        logger.info(
            "tick: exp=%r id=%r step=%r const=%r hc1=%r hc3=%r" %
            (exp_active, exp_id, valve_step, const_param, hc1_out, hc3_out)
        )

        # --- если эксперимент не активен, просто выходим ---
        if not exp_active:
            return

        # --- выбор рабочего клапана ---
        if const_param == "T":
            workValvePath = hc1OutPath
            workOut       = hc1_out
        elif const_param == "CA":
            workValvePath = hc3OutPath
            workOut       = hc3_out
        else:
            logger.warn("Bad CONST_PARAM: %r" % (const_param,))
            return

        # --- шаг клапана ---
        if valve_step > 0.0:
            newOut = workOut + valve_step
            if newOut >= 100.0:
                newOut = 100.0
                # дошли до 100% – записали и остановили эксперимент
                system.tag.writeBlocking([workValvePath], [newOut])
                logger.info("Reached 100%% on %s, stopping experiment" % workValvePath)
                experiment.stop()
                # после stop() EXPERIMENT_ACTIVE станет False, на следующем тике выйдем
            else:
                system.tag.writeBlocking([workValvePath], [newOut])
                logger.info("valve step: %s -> %.1f" % (workValvePath, newOut))

        # --- запись выборки в БД ---
        sql = """
INSERT INTO lab_sample
    (experiment_id, ts, ca_mol_l, cb_mol_l,
     q_l_min, t_c, valve_hc1_pct, valve_trca1_pct)
VALUES (?, CURRENT_TIMESTAMP, ?, ?, ?, ?, ?, ?)
"""

        args = [
            exp_id,
            ca, cb, q_l_min, t_c,
            hc1_out,
            hc3_out,
        ]

        system.db.runPrepUpdate(sql, args, "scada_lab")

    except Exception as e:
        logger.error("Timer error: %s" % e)