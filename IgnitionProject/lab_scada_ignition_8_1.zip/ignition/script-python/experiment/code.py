# project script: experiment

def start():
    import system

    expActiveTag  = "[default]Exp/EXPERIMENT_ACTIVE"
    expIdTag      = "[default]Exp/EXPERIMENT_ID"
    constParamTag = "[default]Exp/CONST_PARAM"
    stepTag       = "[default]Exp/VALVE_STEP_PCT"
    substanceTag  = "[default]Model/Config/SUBSTANCE_ID"

    log = system.util.getLogger("StartExperiment")

    # защита от повторного старта
    expActive = system.tag.readBlocking([expActiveTag])[0].value
    if expActive:
        log.info("Experiment already active, start ignored")
        return

    res = system.tag.readBlocking(
        [substanceTag, constParamTag, stepTag]
    )
    substance_id = res[0].value
    const_param  = res[1].value
    step         = float(res[2].value or 0.0)

    if const_param not in ["T", "CA"]:
        log.warn("Bad CONST_PARAM=%r" % (const_param,))
        return

    if step <= 0.0:
        log.warn("VALVE_STEP_PCT <= 0, start cancelled")
        return

    params = {
        "substance_id":   substance_id,
        "const_param":    const_param,
        "const_value":    None,
        "valve_step_pct": step,
    }
    ds = system.db.runNamedQuery("InsertExperimentRun", params)
    exp_id = ds.getValueAt(0, "id")

    system.tag.writeBlocking(
        [expIdTag, expActiveTag],
        [exp_id, True]
    )

    log.info("Experiment %s started (const=%s, step=%s)" % (exp_id, const_param, step))


def stop():
    import system
    expActiveTag  = "[default]Exp/EXPERIMENT_ACTIVE"
    expIdTag      = "[default]Exp/EXPERIMENT_ID"

    exp_id = system.tag.readBlocking([expIdTag])[0].value

    if exp_id not in (None, 0):
        params = {"id": exp_id}
        system.db.runNamedQuery("FinishExperimentRun", params)

    system.tag.writeBlocking([expActiveTag], [False])