UPDATE lab_experiment_run
SET finished_at = now()
WHERE id = :id;
