SELECT id, name, k01, ea1, k02, ea2
FROM lab_substance
WHERE id = :id;