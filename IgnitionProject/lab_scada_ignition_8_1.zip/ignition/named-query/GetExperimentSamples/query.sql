SELECT
    -- Человекочитаемое время для таблицы/отчёта
    to_char(ts AT TIME ZONE 'UTC', 'YYYY-MM-DD HH24:MI:SS') AS ts,

    -- Время от начала эксперимента в секундах (0, 5, 10, ...)
    EXTRACT(
        EPOCH FROM ts - MIN(ts) OVER ()
    ) AS t_sec,

    ca_mol_l,
    cb_mol_l,
    valve_hc1_pct,
    valve_trca1_pct
FROM lab_sample
WHERE experiment_id = :experiment_id
ORDER BY ts;
