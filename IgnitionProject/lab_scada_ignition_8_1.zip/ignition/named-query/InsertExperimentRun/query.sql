INSERT INTO lab_experiment_run
    (substance_id, const_param, valve_step_pct)
VALUES
    (:substance_id, :const_param, :valve_step_pct)
RETURNING id;
