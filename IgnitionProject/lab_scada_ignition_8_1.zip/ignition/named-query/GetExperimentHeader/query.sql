SELECT e.id,
       e.started_at,
       e.finished_at,
       s.name          AS substance_name,
       e.const_param,
       e.const_value,
       e.valve_step_pct
FROM lab_experiment_run e
JOIN lab_substance s ON s.id = e.substance_id
WHERE e.id = :experiment_id;
