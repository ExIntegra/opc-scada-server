SELECT id, login, role
FROM app_user
WHERE login = :login
  AND password_hash = crypt(:password, password_hash);