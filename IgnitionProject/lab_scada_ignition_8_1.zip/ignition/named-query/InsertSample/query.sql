INSERT INTO lab_sample
    (experiment_id,
     ca_mol_l,
     cb_mol_l,
     q_l_min,
     t_c,
     valve_hc1_pct,
     valve_hc2_pct,
     valve_trca1_pct)
VALUES
    (:experiment_id,
     :ca_mol_l,
     :cb_mol_l,
     :q_l_min,
     :t_c,
     :valve_hc1_pct,
     :valve_hc2_pct,
     :valve_trca1_pct)
RETURNING id;
