def handleTimerEvent():
	import scada_timer
	scada_timer.run()