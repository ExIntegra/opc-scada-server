def onNdefDataReceived(session, data, context):
	