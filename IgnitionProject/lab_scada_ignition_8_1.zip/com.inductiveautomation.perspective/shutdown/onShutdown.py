def onShutdown(session):
	