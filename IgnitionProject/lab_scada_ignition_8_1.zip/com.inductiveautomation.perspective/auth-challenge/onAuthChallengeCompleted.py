def onAuthChallengeCompleted(session, payload, result):
	