def onPageStartup(page):
	