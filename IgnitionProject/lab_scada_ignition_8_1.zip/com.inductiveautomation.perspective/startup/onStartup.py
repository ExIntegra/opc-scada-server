def onStartup(session):
	